/* Imports */
var AWS = require('aws-sdk');
var connectionClass = require('http-aws-es');
var elasticsearch = require('elasticsearch');
var flatten = require('flat');

/* Globals */ 
var esDomain = {
    endpoint: 'https://vpc-guardduty-to-elasticsearch-4oglr4lm5qs4d2vk4iglcinqwq.cn-north-1.es.amazonaws.com.cn',
    region: 'cn-north-1',
    index: 'guarddutylogs',
    doctype: '_doc'
};

var elasticClient = new elasticsearch.Client({  
    host: esDomain.endpoint,
    log: 'error',
    connectionClass: connectionClass,
    amazonES: {
      credentials: new AWS.EnvironmentCredentials('AWS')
    }
});
/*
 * Add the given document to the ES domain.
 * If all records are successfully added, indicate success to lambda
 * (using the "context" parameter).
 */
function postDocumentToES(message, context) {
	
  	var logdata = message.detail;
	console.log("logdata: " + JSON.stringify(logdata) + " id: " + logdata.id);
	var flattened_data = JSON.stringify(flatten(logdata, { maxDepth: 10 }));
	console.log("flattened data: " + flattened_data);
	
	elasticClient.index({
		index: esDomain.index,
		type: esDomain.doctype,
		id: logdata.id,
		body: flattened_data,
	}, function (error, response) {		
		if(error)
			console.log("error : " + error); // Publish the error response
		else
			console.log("response: " + response);
	});
};

exports.handler = function(event, context) {

    console.log('Received event: ', JSON.stringify(event, null, 2));
    
    var final_event;
    console.log(event + " : " + context.awsRequestId);
    if (event.source === "aws.guardduty") {
        final_event = event;
    } else {
        final_event = event;
        return;
    }
	
	// Send the GuardDuty findings as a json object to S3
    postDocumentToES(final_event, context);
};
